int trova_massimo(int N, int V[]) {

    // Inserisci il tuo codice qui

    return 42;
}

#include <vector>
using namespace std;

int trova_massimo(int N, vector<int> V) {

    // Inserisci il tuo codice qui

    return 42;
}

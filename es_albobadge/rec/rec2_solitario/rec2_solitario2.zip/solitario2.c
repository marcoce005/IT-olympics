#include <stdio.h>
#include <assert.h>

int gioca(int N, int M, int** G)
{
    // Mettete qui il codice della soluzione
    return 42;
}


int main()
{
    int N, M;
    assert(2 == scanf("%d %d", &N, &M));

    int** G = (int**) malloc(N * sizeof(int*));
    for(int i = 0; i < N; i++)
        G[i] = (int*) malloc(M * sizeof(int));

    for(int i = 0; i < N; i++)
        for(int j = 0; j < M; j++)
            assert(1 == scanf("%d", &G[i][j]));

    printf("%d\n", gioca(N, M, G));
}

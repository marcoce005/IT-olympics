import java.util.*; 
import java.io.*; 

public class solitario2 {

    private static int gioca(int N, int M, int[][] G) {
        // Mettete qui il codice della soluzione
        return 42;
    }

    public static void main(String[] args) throws FileNotFoundException, IOException {
        InputStream fin = System.in;
        OutputStream fout = System.out;
        // per leggere/scrivere da file 
        //fin = new FileInputStream("cabala.input0.txt");
        //fout = new FileOutputStream("output0.txt");
        Scanner scn = new Scanner(fin); 
        PrintStream prnt = new PrintStream(fout);
        
        int N = scn.nextInt();
        int M = scn.nextInt();
        int[][] G = new int[N][M];
        for (int n=0; n<N; n++)
            for (int m=0; m<M; m++)
                G[n][m] = scn.nextInt();
        prnt.println(gioca(N, M, G));
        prnt.close();
    }
}

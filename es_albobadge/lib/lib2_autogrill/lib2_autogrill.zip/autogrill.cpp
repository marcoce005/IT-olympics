using namespace std;

void inizia() {
    return;
}

void apri(long long p) {
    return;
}

void chiudi(long long p) {
    return;
}

long long chiedi(long long p) {
    return 42;
}

int quadri(int N, long long M, int V[]) {
    // Scrivete qui la vostra soluzione
    int B = 42;
    return B;
}

long long paletta_sort(int N, int V[]) {
    return N;
}


#!/usr/bin/env python3
# NOTE: it is recommended to use this even if you don't understand the following code.

# input data
R, C = map(int, input().strip().split())
M = [None] * R
for i in range(R):
    M[i] = list(map(int, input().strip().split()))


# insert your code here


print(42)  # print the result

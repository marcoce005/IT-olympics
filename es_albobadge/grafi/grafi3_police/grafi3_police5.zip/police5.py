#!/usr/bin/env python3
# NOTE: it is recommended to use this even if you don't understand the following code.


# input data
N, M, T = map(int, input().strip().split())
A = list(map(int, input().strip().split()))
B = list(map(int, input().strip().split()))
C = list(map(int, input().strip().split()))
E = list(map(int, input().strip().split()))


# insert your code here


print(42)  # print the result
